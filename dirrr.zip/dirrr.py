import pygame, pygame.gfxdraw, os

def picture(file):
    formats = ['.png', '.bmp', '.jpg', '.jpeg', '.JPG']
    for form in formats:
        if form in file:
            return True
    return False
def main():
    path = os.path.dirname(__file__)

    tmp = os.listdir()
    files = []
    for file in tmp:
        if picture(file):
            files.append(file)
    print(files)
    for file in files:
        org = pygame.image.load(path+f'\\{file}')
        orgSize = org.get_size()

        new = pygame.Surface((orgSize[0]*2, orgSize[1]*2))
        newSize = new.get_size()
        newFileName = file.split('.')[0]

        for y in range(orgSize[1]):
            for x in range(orgSize[0]):
                color = org.get_at((x,y))
                pygame.gfxdraw.pixel(new, 2*x, 2*y, color)
                pygame.gfxdraw.pixel(new, 2*x+1, 2*y, color)
                pygame.gfxdraw.pixel(new, 2*x, 2*y+1, color)
                pygame.gfxdraw.pixel(new, 2*x+1, 2*y+1, color)
        print(f'finished: {newFileName}')
        pygame.image.save(new, f"a\\{newFileName}.png")
main()
